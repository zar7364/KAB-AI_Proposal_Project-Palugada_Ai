# Palugada Agent v5.8

Pembaruan:
- menambahkan pembuka yang lebih akrab:
  - **"Boleh saya tahu nama Kakak dulu? Biar saya bisa panggil lebih akrab selama kita ngobrol."**
- jika user belum menyebut nama, bot akan bertanya nama satu kali di awal tanpa menghilangkan konteks belanja
- jika user menyebut nama, bot menyimpan:
  - nama lengkap
  - nama panggilan depan
- ekstraksi nama dibuat lebih ketat agar kalimat pencarian produk tidak salah dianggap sebagai nama customer
- agent tidak lagi menyapa customer dengan kata **"kamu"** atau **"anda"**, dan dipaksa konsisten memakai sapaan akrab
- jika customer sudah fokus pada 1 produk, agent tetap membahas produk itu sampai customer jelas meminta alternatif lain
- teknik negosiasi dibuat lebih manusiawi dengan pendekatan ala Chris Voss:
  - tactical empathy
  - labeling kebutuhan / keberatan customer
  - mirroring singkat bila natural
  - calibrated question seperlunya
- sapaan berikutnya lebih natural:
  - Kakak {nama lengkap}
  - Kak {nama depan}
- kemampuan konteks v5.7 tetap dipertahankan:
  - tidak keluar konteks
  - tetap fokus pada produk yang sedang dibahas
  - lebih peka pada interest customer

----
eksekusi serve :
uvicorn app.main:app --reload --host 0.0.0.0
