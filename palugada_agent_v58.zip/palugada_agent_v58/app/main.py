from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import csv, uuid, requests, math, json, re
from pathlib import Path
from typing import List, Dict
import qrcode

BASE_DIR = Path(__file__).resolve().parent.parent
DATASET = BASE_DIR / "data" / "products.csv"
STATIC_DIR = BASE_DIR / "app" / "static"
INVOICE_DIR = STATIC_DIR / "invoices"
DATASTORE_DIR = BASE_DIR / "data" / "runtime"
DATASTORE_DIR.mkdir(parents=True, exist_ok=True)
INVOICE_DIR.mkdir(parents=True, exist_ok=True)

ORDERS_JSON = DATASTORE_DIR / "orders.json"
INVOICES_JSON = DATASTORE_DIR / "invoices.json"
SESSIONS_JSON = DATASTORE_DIR / "sessions.json"
CUSTOMERS_JSON = DATASTORE_DIR / "customers.json"

OLLAMA_URL = "http://localhost:11434/api/generate"
# OLLAMA_MODEL = "qwen2.5:7b"
OLLAMA_MODEL = "llama3:latest"

app = FastAPI(title="Palugada Agent v5.8")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "app" / "templates"))

products: List[Dict] = []
sessions: Dict[str, Dict] = {}
invoices: Dict[str, Dict] = {}
orders: Dict[str, Dict] = {}
customers: Dict[str, Dict] = {}

def save_json(path: Path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def load_json(path: Path, default):
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return default
    return default

def persist_all():
    save_json(SESSIONS_JSON, sessions)
    save_json(INVOICES_JSON, invoices)
    save_json(ORDERS_JSON, orders)
    save_json(CUSTOMERS_JSON, customers)

def parse_numeric_from_name(name: str, suffixes: list[str]) -> str | None:
    for s in suffixes:
        m = re.search(rf"(\d+(?:\.\d+)?)\s*{re.escape(s)}\b", name.lower())
        if m:
            return m.group(1)
    return None

def enrich_product(p: Dict) -> Dict:
    name = p["name"]
    category = p["category"]
    info = {
        "id": p["id"],
        "category": category,
        "name": name,
        "description": p["description"],
        "tags": p.get("tags", ""),
        "price": int(p["price"]),
        "stock": int(p["stock"]),
        "image_url": p["image_url"],
        "specs": {},
    }
    if category == "smart_tv":
        inch = parse_numeric_from_name(name, ["inch"])
        info["specs"] = {
            "ukuran_layar": f"{inch} inch" if inch else "tidak disebutkan",
            "resolusi": "4K / Full HD sesuai seri",
            "konektivitas": "WiFi, streaming app ready",
            "kegunaan": "cocok untuk hiburan keluarga dan ruang tengah",
        }
    elif category == "kulkas":
        liter = parse_numeric_from_name(name, ["l"])
        info["specs"] = {
            "kapasitas": f"{liter} liter" if liter else "tidak disebutkan",
            "pendinginan": "stabil dan hemat listrik",
            "kegunaan": "cocok untuk rumah tangga harian",
        }
    elif category == "rice_cooker":
        liter = parse_numeric_from_name(name, ["l"])
        info["specs"] = {
            "kapasitas": f"{liter} liter" if liter else "tidak disebutkan",
            "lapisan": "anti lengket",
            "fitur": "warm otomatis untuk menjaga nasi tetap hangat",
        }
    elif category == "mesin_cuci":
        kg = parse_numeric_from_name(name, ["kg"])
        info["specs"] = {
            "kapasitas": f"{kg} kg" if kg else "tidak disebutkan",
            "mode": "otomatis dan hemat air",
            "kegunaan": "cocok untuk kebutuhan keluarga",
        }
    elif category == "ac":
        pk = parse_numeric_from_name(name, ["pk"])
        info["specs"] = {
            "kapasitas": f"{pk} PK" if pk else "tidak disebutkan",
            "karakter": "low watt / pendinginan cepat sesuai seri",
            "kegunaan": "cocok untuk kamar atau ruang keluarga kecil",
        }
    return info

def load_products():
    global products
    products = []
    with open(DATASET, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            products.append(enrich_product(r))

load_products()
sessions = load_json(SESSIONS_JSON, {})
invoices = load_json(INVOICES_JSON, {})
orders = load_json(ORDERS_JSON, {})
customers = load_json(CUSTOMERS_JSON, {})

def health_ollama():
    try:
        r = requests.get("http://localhost:11434/api/tags", timeout=5)
        data = r.json()
        models = [m.get("name") for m in data.get("models", [])]
        return {
            "connected": True,
            "model": OLLAMA_MODEL,
            "available_models": models,
            "model_available": OLLAMA_MODEL in models
        }
    except Exception as e:
        return {
            "connected": False,
            "model": OLLAMA_MODEL,
            "available_models": [],
            "model_available": False,
            "error": str(e)
        }

def ask_ollama(prompt: str, fallback: str) -> str:
    prompt = (
        "Selalu balas dalam Bahasa Indonesia yang natural. "
        "Jangan gunakan bahasa asing, jangan gunakan karakter Mandarin, Hanzi, atau tulisan China. "
        "Jika ragu, tetap jawab singkat dalam Bahasa Indonesia.\n\n"
        + prompt
    )
    try:
        payload = {"model": OLLAMA_MODEL, "prompt": prompt, "stream": False}
        r = requests.post(OLLAMA_URL, json=payload, timeout=35)
        r.raise_for_status()
        data = r.json()
        text = data.get("response", "").strip()
        if not text:
            return sanitize_agent_reply(fallback)
        if contains_cjk(text):
            return sanitize_agent_reply(fallback)
        cleaned = sanitize_agent_reply(text)
        if not cleaned or len(cleaned) < max(12, len(fallback) // 4):
            return sanitize_agent_reply(fallback)
        return cleaned
    except Exception:
        return sanitize_agent_reply(fallback)

def contains_cjk(text: str) -> bool:
    return bool(re.search(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]", text or ""))

def sanitize_agent_reply(text: str) -> str:
    if not text:
        return text
    cleaned = text.strip()
    replacements = [
        (r"\b[Kk]amu\b", "Kakak"),
        (r"\b[Aa]nda\b", "Kakak"),
        (r"\b[Kk]alian\b", "Kakak"),
    ]
    for pattern, replacement in replacements:
        cleaned = re.sub(pattern, replacement, cleaned)
    cleaned = re.sub(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]+", " ", cleaned)
    cleaned = re.sub(r"\b(?:nihao|xiexie|duihua|jieshu|qing|gaosu)\b", " ", cleaned, flags=re.I)
    cleaned = re.sub(r"\s+\n", "\n", cleaned)
    cleaned = re.sub(r"[ \t]{2,}", " ", cleaned)
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    return cleaned

def tokenize(text: str):
    return [t.strip().lower() for t in re.sub(r"[?,.!/]", " ", text).split() if t.strip()]

def infer_category(message: str) -> str | None:
    m = message.lower()
    mapping = {
        "smart_tv": ["tv", "televisi", "smart tv", "android tv"],
        "kulkas": ["kulkas", "lemari es"],
        "rice_cooker": ["rice cooker", "magic com", "penanak nasi", "ricecooker"],
        "mesin_cuci": ["mesin cuci"],
        "ac": ["ac", "air conditioner", "pendingin"]
    }
    for cat, words in mapping.items():
        for w in words:
            if w in m:
                return cat
    return None

def search_products(message: str) -> List[Dict]:
    category = infer_category(message)
    toks = tokenize(message)
    scored = []
    for p in products:
        score = 0.0
        hay = f"{p['category']} {p['name']} {p['description']} {p['tags']}".lower()
        if category and p["category"] == category:
            score += 6
        for t in toks:
            if t in hay:
                score += 1
        if "keluarga" in message.lower() and any(k in hay for k in ["keluarga", "ruang keluarga", "layar besar"]):
            score += 1.5
        if "hemat listrik" in message.lower() and "hemat" in hay:
            score += 1.5
        if "low watt" in message.lower() and any(k in hay for k in ["low watt", "hemat", "ac"]):
            score += 1.5
        if p["stock"] > 0:
            score += 0.2
        if score > 0:
            scored.append((score, p))
    scored.sort(key=lambda x: (-x[0], x[1]["price"]))
    return [p for _, p in scored[:3]]

def rupiah(value: int) -> str:
    return f"Rp{value:,}".replace(",", ".")

def normalize_person_name(name: str | None) -> str | None:
    if not name:
        return None
    cleaned = re.sub(r"\s+", " ", name).strip(" .,!?:;")
    if not cleaned:
        return None
    words = []
    for part in cleaned.split():
        plain = part.strip(".")
        if plain.lower() in {"kak", "kakak", "mas", "mbak", "pak", "bu", "om", "bro", "sis"}:
            continue
        words.append(plain)
    if not words:
        return None
    return " ".join(w[:1].upper() + w[1:] for w in words if w)

def first_name(full_name: str | None) -> str:
    normalized = normalize_person_name(full_name)
    if not normalized:
        return "Kak"
    return normalized.split()[0]

def display_name(full_name: str | None) -> str:
    normalized = normalize_person_name(full_name)
    if not normalized:
        return "Kakak"
    return f"Kakak {normalized}"

def friendly_call(session: Dict) -> str:
    preferred = normalize_person_name(session.get("preferred_callname"))
    if preferred:
        return f"Kak {preferred}"
    full_name = normalize_person_name(session.get("customer_name"))
    if full_name:
        return f"Kak {first_name(full_name)}"
    return "Kak"

def known_customer_name(session: Dict) -> str:
    full_name = normalize_person_name(session.get("customer_name"))
    if full_name:
        return full_name
    preferred = normalize_person_name(session.get("preferred_callname"))
    if preferred:
        return preferred
    return "Kakak"

def recent_context(session: Dict, max_items: int = 6) -> str:
    msgs = session.get("messages", [])[-max_items:]
    lines = []
    for m in msgs:
        role = "Customer" if m["role"] == "user" else "Agent"
        lines.append(f"{role}: {m['text']}")
    return "\n".join(lines)

def get_session(session_id: str):
    if session_id not in sessions:
        sessions[session_id] = {
            "messages": [],
            "selected_product": None,
            "last_offer": None,
            "state": "browsing",
            "customer_name": None,
            "address": None,
            "phone": None,
            "invoice_id": None,
            "conversation_count": 0,
            "upsell_used": False,
            "last_recommendations": [],
            "last_paid_invoice_id": None,
            "greeted_returning": False,
            "customer_interest": None,
            "last_intent": None,
            "asked_name_once": False,
            "preferred_callname": None,
        }
        persist_all()
    return sessions[session_id]

def reset_for_new_purchase(session: Dict):
    session["selected_product"] = None
    session["last_offer"] = None
    session["state"] = "browsing"
    session["invoice_id"] = None
    session["conversation_count"] = 0
    session["upsell_used"] = False
    session["last_recommendations"] = []
    session["greeted_returning"] = False
    session["customer_interest"] = None
    session["last_intent"] = None
    persist_all()

def negotiate_price(product: Dict, user_offer: int | None):
    price_max = int(product["price"])
    price_min = int(math.floor(price_max * 0.85 / 1000) * 1000)
    if user_offer is None:
        return {"status": "offer", "price": price_max}
    if user_offer >= price_max:
        return {"status": "deal", "price": price_max}
    if user_offer >= price_min:
        return {"status": "deal", "price": user_offer}
    if user_offer < int(price_min * 0.9):
        counter = max(price_min, int(round((price_max * 0.92) / 1000) * 1000))
        return {"status": "counter", "price": counter}
    counter = max(price_min, int(round((user_offer + price_max)/2 / 1000) * 1000))
    return {"status": "counter", "price": counter}

def extract_price(text: str):
    cleaned = text.lower().replace("rp", "").replace(".", "").replace(",", "")
    m = re.search(r"(\d{5,12})", cleaned)
    return int(m.group(1)) if m else None

def extract_shipping(text: str):
    parts = [p.strip() for p in text.split(",")]
    if len(parts) < 3:
        return None
    return {
        "name": parts[0],
        "address": ", ".join(parts[1:-1]),
        "phone": parts[-1],
    }

def looks_like_name_candidate(text: str) -> bool:
    candidate = (text or "").strip()
    if not candidate or len(candidate) > 60:
        return False
    lowered = candidate.lower()
    if any(ch.isdigit() for ch in candidate):
        return False
    if any(mark in lowered for mark in ["?", "!", "@", "#", "/", "\\"]):
        return False
    banned_phrases = [
        "ada ", "cari ", "mau ", "butuh ", "kulkas", "tv", "televisi", "ac", "rice cooker",
        "magic com", "mesin cuci", "smart tv", "harga", "berapa", "yang bagus", "keluarga",
        "boleh", "tolong", "produk", "stok", "checkout", "bayar", "alamat", "nomor hp"
    ]
    if any(phrase in lowered for phrase in banned_phrases):
        return False
    words = [w for w in re.split(r"\s+", candidate) if w]
    if not words or len(words) > 4:
        return False
    stopwords = {
        "saya", "nama", "aku", "mau", "cari", "ada", "yang", "untuk", "dan",
        "di", "ke", "dari", "dengan", "pakai", "tolong", "boleh"
    }
    greeting_words = {
        "halo", "haloo", "hallo", "hello", "helo", "hai", "hi", "hy",
        "pagi", "siang", "sore", "malam", "permisi", "tes", "test", "cek"
    }
    alpha_words = 0
    for word in words:
        stripped = word.strip(".-'")
        if not stripped:
            return False
        if stripped.lower() in stopwords:
            return False
        if stripped.lower() in greeting_words:
            return False
        if not re.fullmatch(r"[A-Za-z][A-Za-z\.\-']*", word):
            return False
        alpha_words += 1
    return alpha_words >= 1

def explicit_name_patterns() -> list[str]:
    return [
        r"(?:nama saya|namaku|aku|saya)\s+(?:adalah\s+)?([A-Za-z][A-Za-z\s\.\-']{1,60})$",
        r"(?:saya\s+atas\s+nama|atas\s+nama)\s+([A-Za-z][A-Za-z\s\.\-']{1,60})$",
        r"(?:panggil\s+(?:saya|aku)|bisa\s+panggil\s+(?:saya|aku))\s+([A-Za-z][A-Za-z\s\.\-']{1,60})$",
    ]

def has_explicit_name_intro(text: str) -> bool:
    stripped = text.strip()
    return any(re.search(pattern, stripped, re.I) for pattern in explicit_name_patterns())

def maybe_extract_name(text: str, allow_single_word: bool = False):
    explicit_patterns = explicit_name_patterns()
    stripped = text.strip()
    for pattern in explicit_patterns:
        match = re.search(pattern, stripped, re.I)
        if match:
            candidate = normalize_person_name(match.group(1))
            if looks_like_name_candidate(candidate or ""):
                return candidate
    plain_words = [w for w in re.split(r"\s+", stripped) if w]
    if looks_like_name_candidate(stripped) and (allow_single_word or len(plain_words) >= 2):
        return normalize_person_name(stripped)
    return None

def wants_checkout(msg: str) -> bool:
    m = msg.lower()
    triggers = ["checkout", "check out", "langsung checkout", "mau checkout", "langsung bayar", "buat invoice", "kirim invoice", "lanjut bayar", "cukup yang tadi", "yang tadi saja"]
    return any(t in m for t in triggers)

def wants_best_price(msg: str) -> bool:
    m = msg.lower()
    triggers = ["best price", "bestprice", "harga terbaik", "harga pas", "kasih terbaik", "special price", "spesial price", "harga terbaiknya", "kasih harga terbaik", "nego harga", "turunin harga"]
    return any(t in m for t in triggers)

def wants_switch_product(message: str, session: Dict) -> bool:
    selected = session.get("selected_product")
    if not selected:
        return False
    lowered = message.lower()
    switch_triggers = [
        "produk lain", "barang lain", "opsi lain", "alternatif", "yang lain",
        "cari ", "ada ", "mau lihat ", "mau cari ", "lihat yang "
    ]
    if any(trigger in lowered for trigger in switch_triggers):
        return True
    mentioned_category = infer_category(message)
    return bool(mentioned_category and mentioned_category != selected.get("category"))

def build_voss_style_rules() -> str:
    return (
        "- pakai tactical empathy: akui kebutuhan atau keberatan customer secara singkat\n"
        "- boleh mirror 1-3 kata penting dari ucapan customer bila terasa natural\n"
        "- boleh pakai label halus seperti 'kelihatannya', 'berarti', atau 'jadi yang dicari'\n"
        "- bila perlu bertanya, pakai maksimal 1 calibrated question yang singkat\n"
        "- jangan manipulatif, jangan bertele-tele, dan jangan terdengar seperti skrip"
    )

def focused_product_reply(session: Dict, message: str) -> str:
    product = session.get("selected_product")
    if not product:
        return f"Siap {friendly_call(session)}, sebutkan dulu produk yang sedang dicari ya."
    customer = friendly_call(session)
    prompt = f"""
Anda adalah agen negosiator marketplace yang hangat, fokus, dan sangat disiplin konteks.
Customer saat ini sedang membahas tepat 1 produk: {product['name']} dari kategori {product['category']}.
Sapa customer dengan {customer}. Jangan gunakan kata "kamu" atau "anda".
Jangan rekomendasikan produk lain. Jangan pindah topik. Jangan mengarang detail.
Balas hanya untuk membantu customer melanjutkan pembahasan produk ini.
Gunakan gaya ala Chris Voss secara natural:
{build_voss_style_rules()}
Jawaban maksimal 4 kalimat.

Konteks percakapan:
{recent_context(session)}

Info produk aktif:
- Nama: {product['name']}
- Deskripsi: {product['description']}
- Harga saat ini: {rupiah(int(session.get('last_offer') or product['price']))}
- Stok: {product['stock']}

Pesan customer:
{message}
"""
    fallback = f"Siap {customer}, untuk saat ini kita fokus di {product['name']} dulu ya. Kalau ada yang mau ditanyakan atau mau lanjut nego untuk produk ini, saya bantu."
    return ask_ollama(prompt, fallback)

def is_product_question(msg: str) -> bool:
    m = msg.lower()
    keywords = ["spesifikasi", "spec", "fitur", "ukuran", "kapasitas", "watt", "konsumsi", "kelebihan", "cocok", "untuk apa", "bedanya", "gimana", "seperti apa", "garansi", "wifi", "netflix", "youtube", "detail", "itu", "produk itu"]
    return any(k in m for k in keywords)

def choose_reco_from_context(session: Dict) -> Dict | None:
    if session.get("selected_product"):
        return session["selected_product"]
    recos = session.get("last_recommendations") or []
    return recos[0] if recos else None

def answer_product_question(session: Dict, message: str):
    product = choose_reco_from_context(session)
    if not product:
        return None
    customer = friendly_call(session)
    specs = "\n".join([f"- {k.replace('_', ' ').title()}: {v}" for k, v in product.get("specs", {}).items()])
    prompt = f"""
Anda adalah agen negosiator marketplace yang ramah, tajam, dan peka konteks.
Fokus hanya pada produk yang sedang dibahas customer.
Panggil customer dengan {customer}. Jangan gunakan kata "kamu" atau "anda".
Gunakan hanya knowledge produk berikut. Kalau info belum ada, bilang jujur bahwa detail itu belum tercantum.
Jangan mengarang. Jangan keluar konteks. Jangan menawarkan produk lain kecuali diminta.
Gunakan gaya ala Chris Voss secara natural:
{build_voss_style_rules()}
Jawaban natural, ramah, ringkas, maksimal 5 kalimat.

Konteks percakapan:
{recent_context(session)}

Knowledge produk:
Nama: {product['name']}
Kategori: {product['category']}
Deskripsi: {product['description']}
Tags: {product['tags']}
Harga normal: {rupiah(product['price'])}
Stok: {product['stock']}
Spesifikasi:
{specs}

Pertanyaan customer:
{message}
"""
    fallback = f"Siap {customer}, untuk {product['name']} ini {product['description']}. Detail yang tercatat: " + ", ".join([f"{k.replace('_',' ')} {v}" for k, v in product.get("specs", {}).items()]) + ". Kalau ada detail tertentu yang mau ditanyakan, sebutkan saja ya."
    return ask_ollama(prompt, fallback)

def one_time_upsell(session: Dict, product_name: str) -> str:
    if session.get("upsell_used"):
        return ""
    session["upsell_used"] = True
    persist_all()
    prompt = f"""
Buat 1 kalimat upsell yang singkat, sopan, dan tidak memaksa.
Produk: {product_name}
Gaya: "Kalau Kakak ambil lebih dari 1 unit, aku bisa bantu special price juga."
Maksimal 1 kalimat.
"""
    fallback = "Kalau Kakak ambil lebih dari 1 unit, aku bisa bantu special price juga."
    return ask_ollama(prompt, fallback)

def short_sales_reply(message: str, recs: List[Dict], session: Dict):
    best = recs[0]
    session["selected_product"] = best
    session["last_offer"] = best["price"]
    session["state"] = "product_selected"
    session["conversation_count"] += 1
    session["last_recommendations"] = recs
    session["customer_interest"] = infer_category(message) or best["category"]
    session["last_intent"] = "recommendation"
    persist_all()

    customer = friendly_call(session)
    listing = "\n".join([f"{i+1}. {p['name']} - {rupiah(p['price'])}" for i, p in enumerate(recs)])
    extra = ""
    if not session["upsell_used"]:
        extra = " Tambahkan maksimal 1 kalimat upsell saja."
    prompt = f"""
Anda adalah agen negosiator marketplace yang ramah, fokus, dan peka konteks.
Customer sedang tertarik pada kategori {session['customer_interest']}.
Panggil customer dengan {customer}. Jangan gunakan kata "kamu" atau "anda".
Tampilkan 3 produk berikut secara natural dan singkat:
{listing}

Aturan:
- jangan keluar konteks kategori yang sedang dicari
- jadikan {best['name']} sebagai rekomendasi utama, dua lainnya hanya pembanding singkat
- jangan tanya balik terlalu banyak
- akui kebutuhan customer secara singkat sebelum menawarkan pilihan
- gunakan gaya ala Chris Voss secara natural:
{build_voss_style_rules()}
- cukup 4-6 baris
- tutup dengan ajakan halus: customer bisa pilih salah satu, tanya detail produknya, atau langsung checkout
- jangan memaksa.{extra}
"""
    fallback = (
        f"{customer}, ini 3 pilihan yang paling cocok ya:\n"
        f"1. {recs[0]['name']} - {rupiah(recs[0]['price'])}\n"
        f"2. {recs[1]['name']} - {rupiah(recs[1]['price'])}\n"
        f"3. {recs[2]['name']} - {rupiah(recs[2]['price'])}\n"
        f"Kalau mau, {customer} bisa pilih salah satu, tanya detail produknya, atau langsung checkout."
    )
    return ask_ollama(prompt, fallback)

def ensure_checkout_reply(session: Dict):
    product = choose_reco_from_context(session)
    if not product:
        return f"Siap {friendly_call(session)}, pilih dulu produknya ya.", False
    session["selected_product"] = product
    if not session.get("last_offer"):
        session["last_offer"] = product["price"]
    session["state"] = "awaiting_shipping"
    session["last_intent"] = "checkout"
    persist_all()

    if session.get("customer_name") and session.get("address") and session.get("phone"):
        session["state"] = "ready_invoice"
        persist_all()
        fallback = f"Senang hati melayani {friendly_call(session)} lagi. Data pengiriman sudah tersimpan, tinggal klik tombol Buat Invoice ya."
        return fallback, True

    prompt = f"""
Customer mau langsung checkout untuk produk {product['name']} di harga {rupiah(session['last_offer'])}.
Jangan jualan lagi. Jangan rekomendasikan produk lain.
Jangan gunakan kata "kamu" atau "anda".
Jawab singkat sekali dan langsung minta: Nama, Alamat lengkap, Nomor HP.
"""
    fallback = f"Siap {friendly_call(session)}, langsung checkout ya untuk {product['name']} di {rupiah(session['last_offer'])}. Kirim ya: Nama, Alamat lengkap, Nomor HP."
    return ask_ollama(prompt, fallback), True

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/api/health/ollama")
async def api_health_ollama():
    return health_ollama()

@app.post("/api/session")
async def create_session():
    sid = str(uuid.uuid4())
    get_session(sid)
    return {"session_id": sid, "greeting": "Mari Kakak, ada yang bisa kami bantu?"}

@app.post("/api/chat")
async def chat(payload: dict):
    session_id = payload.get("session_id")
    message = (payload.get("message") or "").strip()
    if not session_id or not message:
        return JSONResponse({"error": "session_id dan message wajib diisi"}, status_code=400)

    session = get_session(session_id)
    session["messages"].append({"role": "user", "text": message})

    extracted_name = maybe_extract_name(message, allow_single_word=bool(session.get("asked_name_once")))
    explicit_name_intro = has_explicit_name_intro(message)
    intro_only = bool(
        extracted_name and (
            message.lower().strip() == extracted_name.lower()
            or explicit_name_intro
        )
    )

    if extracted_name and (explicit_name_intro or session.get("asked_name_once") or not session.get("customer_name")):
        current_name = normalize_person_name(session.get("customer_name"))
        if current_name != extracted_name:
            session["customer_name"] = extracted_name
            session["preferred_callname"] = first_name(extracted_name)
            session["greeted_returning"] = False
            persist_all()
        if intro_only and not infer_category(message):
            reply = f"Senang kenal ya, {friendly_call(session)}. Silakan sebutkan produk yang sedang dicari, nanti saya bantu carikan yang paling cocok."
            session["messages"].append({"role": "assistant", "text": reply})
            persist_all()
            return {"reply": reply, "products": [], "state": session["state"], "hide_products": True}

    if not session.get("customer_name"):
        if not session.get("asked_name_once"):
            session["asked_name_once"] = True
            persist_all()
            name_prompt = "Boleh saya tahu nama Kakak dulu? Biar saya bisa panggil lebih akrab selama kita ngobrol."
            recs = search_products(message)
            if recs:
                reply = name_prompt + "\n\n" + short_sales_reply(message, recs, session)
                session["messages"].append({"role": "assistant", "text": reply})
                persist_all()
                return {"reply": reply, "products": recs, "state": session["state"], "can_hide_products": True}
            reply = name_prompt
            session["messages"].append({"role": "assistant", "text": reply})
            persist_all()
            return {"reply": reply, "products": [], "state": session["state"], "hide_products": True}

    if session.get("invoice_id"):
        inv = invoices.get(session["invoice_id"])
        if inv and inv.get("paid"):
            session["last_paid_invoice_id"] = session["invoice_id"]
            reset_for_new_purchase(session)
            if session.get("customer_name") and not session.get("greeted_returning"):
                greet = f"Senang hati melayani {friendly_call(session)} untuk belanja lagi. Jangan khawatir, saya bantu carikan best price juga ya."
                session["greeted_returning"] = True
                session["messages"].append({"role": "assistant", "text": greet})
                persist_all()

    if wants_checkout(message):
        reply, ok = ensure_checkout_reply(session)
        session["messages"].append({"role": "assistant", "text": reply})
        persist_all()
        show_invoice = session["state"] == "ready_invoice"
        return {"reply": reply, "products": [], "state": session["state"], "hide_products": True, "show_invoice_button": show_invoice}

    if session["state"] == "awaiting_shipping":
        data = extract_shipping(message)
        if not data:
            reply = f"Siap {friendly_call(session)}, kirim format: Nama, Alamat lengkap, Nomor HP."
            session["messages"].append({"role": "assistant", "text": reply})
            persist_all()
            return {"reply": reply, "products": [], "state": session["state"], "hide_products": True}
        session["customer_name"] = data["name"]
        session["preferred_callname"] = first_name(data["name"])
        session["address"] = data["address"]
        session["phone"] = data["phone"]
        customers[data["phone"]] = {"name": data["name"], "address": data["address"], "phone": data["phone"]}
        session["state"] = "ready_invoice"
        session["last_intent"] = "invoice"

        inv_preview = f"{rupiah(int(session.get('last_offer') or session['selected_product']['price']))}"
        prompt = f"""
User sudah kirim data pengiriman.
Jangan jualan lagi. Jangan rekomendasikan produk lain.
Sapa dengan {friendly_call(session)}.
Jangan gunakan kata "kamu" atau "anda".
Jawab singkat sekali.
Katakan data sudah masuk dan arahkan ke tombol invoice.
Nominal invoice: {inv_preview}
"""
        fallback = f"Siap {friendly_call(session)}, data pengiriman sudah masuk. Tinggal klik tombol Buat Invoice ya."
        reply = ask_ollama(prompt, fallback)
        session["messages"].append({"role": "assistant", "text": reply})
        persist_all()
        return {"reply": reply, "products": [], "state": session["state"], "show_invoice_button": True, "hide_products": True}

    if message.lower() in ["deal", "oke deal", "setuju", "saya ambil", "ok deal"]:
        if session["selected_product"] and session["last_offer"]:
            session["state"] = "awaiting_shipping"
            session["last_intent"] = "deal"
            if session.get("customer_name") and session.get("address") and session.get("phone"):
                session["state"] = "ready_invoice"
                reply = f"Siap {friendly_call(session)}, data pengiriman sudah tersimpan. Tinggal klik tombol Buat Invoice ya."
                session["messages"].append({"role": "assistant", "text": reply})
                persist_all()
                return {"reply": reply, "products": [], "state": session["state"], "show_invoice_button": True, "hide_products": True}
            prompt = f"""
User sudah deal untuk {session['selected_product']['name']} di {rupiah(session['last_offer'])}.
Jangan gunakan kata "kamu" atau "anda".
Jawab sangat singkat, lalu minta: Nama, Alamat lengkap, Nomor HP.
"""
            fallback = f"Siap {friendly_call(session)}, deal di {rupiah(session['last_offer'])}. Kirim ya: Nama, Alamat lengkap, Nomor HP."
            reply = ask_ollama(prompt, fallback)
            session["messages"].append({"role": "assistant", "text": reply})
            persist_all()
            return {"reply": reply, "products": [], "state": session["state"], "hide_products": True}

    if session["selected_product"] and is_product_question(message):
        session["last_intent"] = "product_question"
        reply = answer_product_question(session, message)
        session["messages"].append({"role": "assistant", "text": reply})
        persist_all()
        return {"reply": reply, "products": [], "state": session["state"], "hide_products": True}

    if session["selected_product"]:
        if wants_best_price(message):
            nego = negotiate_price(session["selected_product"], int(session["selected_product"]["price"] * 0.9))
            session["last_offer"] = nego["price"]
            session["conversation_count"] += 1
            session["last_intent"] = "negotiation"
            customer = friendly_call(session)
            prompt = f"""
Anda adalah agen negosiator marketplace yang hangat, tenang, dan disiplin konteks.
Customer sedang membahas produk {session['selected_product']['name']}.
Customer minta best price.
Best price backend: {rupiah(nego['price'])}.
Sapa dengan {customer}. Jangan gunakan kata "kamu" atau "anda".
Jangan menawarkan produk lain. Jangan keluar konteks.
Gunakan gaya ala Chris Voss secara natural:
{build_voss_style_rules()}
Jawab singkat, natural, dan tutup dengan ajakan halus untuk checkout kalau cocok.
"""
            fallback = f"Siap {customer}, best price untuk {session['selected_product']['name']} aku bantu di {rupiah(nego['price'])}. Kalau cocok, langsung checkout aja ya."
            reply = ask_ollama(prompt, fallback)
            session["messages"].append({"role": "assistant", "text": reply})
            persist_all()
            return {"reply": reply, "products": [], "state": "negotiating", "hide_products": True}

        user_offer = extract_price(message)
        if user_offer:
            nego = negotiate_price(session["selected_product"], user_offer)
            session["last_offer"] = nego["price"]
            session["conversation_count"] += 1
            session["last_intent"] = "negotiation"
            customer = friendly_call(session)
            if nego["status"] == "deal":
                session["state"] = "awaiting_shipping"
                if session.get("customer_name") and session.get("address") and session.get("phone"):
                    session["state"] = "ready_invoice"
                    reply = f"Siap {customer}, aku setujui di {rupiah(nego['price'])}. Data pengiriman sudah tersimpan, tinggal klik tombol Buat Invoice ya."
                    session["messages"].append({"role": "assistant", "text": reply})
                    persist_all()
                    return {"reply": reply, "products": [], "state": session["state"], "show_invoice_button": True, "hide_products": True}
                prompt = f"""
Backend setuju di {rupiah(nego['price'])} untuk {session['selected_product']['name']}.
Sapa dengan {customer}. Jangan gunakan kata "kamu" atau "anda".
Gunakan gaya ala Chris Voss secara natural:
{build_voss_style_rules()}
Jawab sangat singkat, langsung close, lalu minta data pengiriman: Nama, Alamat lengkap, Nomor HP.
"""
                fallback = f"Siap {customer}, aku setujui di {rupiah(nego['price'])}. Langsung kirim ya: Nama, Alamat lengkap, Nomor HP."
                reply = ask_ollama(prompt, fallback)
                session["messages"].append({"role": "assistant", "text": reply})
                persist_all()
                return {"reply": reply, "products": [], "state": session["state"], "hide_products": True}
            else:
                prompt = f"""
Counter resmi backend untuk {session['selected_product']['name']} adalah {rupiah(nego['price'])}.
Sapa dengan {customer}. Jangan gunakan kata "kamu" atau "anda".
Jawab singkat sekali, natural, dan tetap di konteks produk yang sama.
Jangan rekomendasikan produk lain.
Gunakan gaya ala Chris Voss secara natural:
{build_voss_style_rules()}
Tutup dengan: kalau cocok, langsung checkout ya.
"""
                fallback = f"Untuk {customer}, hari ini saya kasih special price {rupiah(nego['price'])} ya. Kalau cocok, langsung checkout aja."
                reply = ask_ollama(prompt, fallback)
                session["messages"].append({"role": "assistant", "text": reply})
                persist_all()
                return {"reply": reply, "products": [], "state": "negotiating", "hide_products": True}

        if not wants_switch_product(message, session):
            session["last_intent"] = "product_followup"
            reply = focused_product_reply(session, message)
            session["messages"].append({"role": "assistant", "text": reply})
            persist_all()
            return {"reply": reply, "products": [], "state": session["state"], "hide_products": True}

    for phone, cust in customers.items():
        if cust["name"].lower() in message.lower():
            session["customer_name"] = cust["name"]
            session["preferred_callname"] = first_name(cust["name"])
            session["address"] = cust["address"]
            session["phone"] = cust["phone"]
            persist_all()
            break

    recs = search_products(message)
    if recs:
        reply = short_sales_reply(message, recs, session)
        if session.get("customer_name") and not session.get("greeted_returning"):
            greet = f"Senang hati melayani {friendly_call(session)} untuk belanja lagi. Jangan khawatir, saya bantu carikan best price juga ya."
            reply = greet + "\n\n" + reply
            session["greeted_returning"] = True
        session["messages"].append({"role": "assistant", "text": reply})
        persist_all()
        return {"reply": reply, "products": recs, "state": session["state"], "can_hide_products": True}

    reply = f"Siap {friendly_call(session)}, sebutkan aja produk yang dicari ya. Misalnya TV, kulkas, AC, rice cooker, atau mesin cuci."
    session["messages"].append({"role": "assistant", "text": reply})
    persist_all()
    return {"reply": reply, "products": [], "state": session["state"], "hide_products": True}

@app.post("/api/select-product")
async def select_product(payload: dict):
    session = get_session(payload.get("session_id"))
    pid = str(payload.get("product_id"))
    product = next((p for p in products if str(p["id"]) == pid), None)
    if not product:
        return JSONResponse({"error": "produk tidak ditemukan"}, status_code=404)
    session["selected_product"] = product
    session["last_offer"] = product["price"]
    session["state"] = "product_selected"
    session["last_intent"] = "product_selected"
    persist_all()
    upsell = one_time_upsell(session, product["name"])
    customer = friendly_call(session)
    prompt = f"""
Anda adalah agen negosiator marketplace yang ramah dan peka konteks.
User memilih {product['name']}.
Sapa dengan {customer}. Jangan gunakan kata "kamu" atau "anda".
Tetap fokus hanya pada produk ini, jangan menawarkan produk lain kecuali diminta.
Gunakan gaya ala Chris Voss secara natural:
{build_voss_style_rules()}
Jawab singkat sekali.
Sebut harga normal {rupiah(product['price'])}.
Arahkan user untuk langsung tanya detail produk, nego, deal, atau checkout.
{upsell}
"""
    fallback = f"Siap {customer}, {product['name']} ready ya. Harga normal {rupiah(product['price'])}. Kalau mau, Kakak bisa tanya detail dulu, nego, atau langsung checkout."
    if upsell:
        fallback += f" {upsell}"
    reply = ask_ollama(prompt, fallback)
    session["messages"].append({"role": "assistant", "text": reply})
    persist_all()
    return {"reply": reply, "product": product, "state": session["state"], "hide_products": True}

@app.post("/api/create-invoice")
async def create_invoice(payload: dict):
    session = get_session(payload.get("session_id"))
    product = session.get("selected_product")
    if not product:
        return JSONResponse({"error": "pilih produk dulu"}, status_code=400)
    if session.get("phone") and session["phone"] in customers and (not session.get("customer_name") or not session.get("address")):
        cust = customers[session["phone"]]
        session["customer_name"] = cust["name"]
        session["address"] = cust["address"]
    if not session.get("customer_name") or not session.get("address") or not session.get("phone"):
        return JSONResponse({"error": "isi data pengiriman dulu"}, status_code=400)

    inv_id = str(uuid.uuid4())[:8]
    amount = int(session.get("last_offer") or product["price"])
    pay_url = f"http://localhost:8000/pay/{inv_id}"

    qr_path = INVOICE_DIR / f"invoice_{inv_id}.png"
    img = qrcode.make(pay_url)
    img.save(qr_path)

    invoices[inv_id] = {
        "id": inv_id,
        "product": product,
        "amount": amount,
        "customer_name": session["customer_name"],
        "address": session["address"],
        "phone": session["phone"],
        "paid": False,
        "session_id": payload.get("session_id"),
        "pay_url": pay_url,
        "qr_url": f"/static/invoices/invoice_{inv_id}.png",
    }
    orders[inv_id] = {
        "invoice_id": inv_id,
        "product_name": product["name"],
        "amount": amount,
        "customer_name": session["customer_name"],
        "address": session["address"],
        "phone": session["phone"],
        "status": "waiting_payment",
    }
    session["invoice_id"] = inv_id
    session["state"] = "awaiting_payment"
    session["last_intent"] = "awaiting_payment"
    persist_all()

    return {
        "invoice_id": inv_id,
        "amount": amount,
        "pay_url": pay_url,
        "qr_url": f"/static/invoices/invoice_{inv_id}.png",
        "invoice_page": f"/invoice/{inv_id}",
    }

@app.get("/invoice/{inv_id}", response_class=HTMLResponse)
async def invoice_page(request: Request, inv_id: str):
    inv = invoices.get(inv_id)
    if not inv:
        return HTMLResponse("Invoice tidak ditemukan", status_code=404)
    return templates.TemplateResponse("invoice.html", {"request": request, "invoice": inv, "rupiah": rupiah})

@app.get("/pay/{inv_id}", response_class=HTMLResponse)
async def pay_page(request: Request, inv_id: str):
    inv = invoices.get(inv_id)
    if not inv:
        return HTMLResponse("Invoice tidak ditemukan", status_code=404)
    return templates.TemplateResponse("pay.html", {"request": request, "invoice": inv, "rupiah": rupiah})

@app.post("/api/confirm-payment/{inv_id}")
async def confirm_payment(inv_id: str):
    inv = invoices.get(inv_id)
    if not inv:
        return JSONResponse({"error": "invoice tidak ditemukan"}, status_code=404)
    inv["paid"] = True
    if inv_id in orders:
        orders[inv_id]["status"] = "paid"
    sid = inv["session_id"]
    session = get_session(sid)
    session["state"] = "paid"
    session["last_paid_invoice_id"] = inv_id
    msg = "Terimakasih kak, atas pembayarannya sudah masuk. Tinggal kami proses untuk pengirimannya."
    session["messages"].append({"role": "assistant", "text": msg})
    persist_all()
    return {"paid": True, "message": msg}

@app.get("/api/check-payment/{inv_id}")
async def check_payment(inv_id: str):
    inv = invoices.get(inv_id)
    if not inv:
        return JSONResponse({"error": "invoice tidak ditemukan"}, status_code=404)
    if inv["paid"]:
        return {"paid": True, "message": "Terimakasih kak, atas pembayarannya sudah masuk. Tinggal kami proses untuk pengirimannya."}
    return {"paid": False}

@app.get("/api/admin/orders")
async def list_orders():
    return {"orders": orders}

@app.get("/api/admin/customers")
async def list_customers():
    return {"customers": customers}
